const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const pool = require("../db");

async function authenticateToken(req, res, next) {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({
                error: "Authentication required"
            });
        }

        const token = authHeader.split(" ")[1];

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        const sessionResult = await pool.query(
            `SELECT * FROM sessions
             WHERE id = $1
             AND user_id = $2
             AND revoked = FALSE
             AND expires_at > NOW()`,
            [decoded.sessionId, decoded.userId]
        );

        if (sessionResult.rows.length === 0) {
            return res.status(401).json({
                error: "Invalid or expired session"
            });
        }

        req.userId = decoded.userId;
        req.sessionId = decoded.sessionId;

        next();

    } catch (error) {
        return res.status(401).json({
            error: "Invalid or expired token"
        });
    }
}

module.exports = authenticateToken;