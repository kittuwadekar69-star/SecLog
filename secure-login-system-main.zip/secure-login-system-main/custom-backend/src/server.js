const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/users");
const fileRoutes = require("./routes/files");
const app = express();

app.use(cors());
app.use(express.json());

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: {
        error: "Too many login attempts. Please try again later."
    }
});

app.use("/api/auth/login", loginLimiter);

app.use("/api/auth", authRoutes);

app.use("/api", userRoutes);

app.use("/api", fileRoutes);

app.get("/", (req, res) => {
    res.json({
        message: "Secure Login API is running"
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});