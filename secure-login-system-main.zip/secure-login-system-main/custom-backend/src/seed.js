const bcrypt = require("bcrypt");
const fs = require("fs");
const path = require("path");
const pool = require("./db");

async function seed() {
    try {
        const users = [
            {
                name: "Alice",
                email: "alice@example.com",
                password: "Alice@123"
            },
            {
                name: "Bob",
                email: "bob@example.com",
                password: "Bob@123"
            },
            {
                name: "Charlie",
                email: "charlie@example.com",
                password: "Charlie@123"
            }
        ];

        const uploadDir = path.join(__dirname, "..", "uploads");

        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }

        for (const user of users) {
            const passwordHash = await bcrypt.hash(user.password, 12);

            const result = await pool.query(
                `INSERT INTO users (name, email, password_hash)
                 VALUES ($1, $2, $3)
                 ON CONFLICT (email)
                 DO UPDATE SET name = EXCLUDED.name
                 RETURNING id`,
                [user.name, user.email, passwordHash]
            );

            const userId = result.rows[0].id;

            const filename = `${user.name.toLowerCase()}-profile.txt`;
            const filePath = path.join(uploadDir, filename);

            fs.writeFileSync(
                filePath,
                `This is ${user.name}'s private file.\n`
            );

            const existingFile = await pool.query(
                `SELECT id FROM files
                 WHERE user_id = $1 AND filename = $2`,
                [userId, filename]
            );

            if (existingFile.rows.length === 0) {
                await pool.query(
                    `INSERT INTO files
                     (user_id, filename, file_path)
                     VALUES ($1, $2, $3)`,
                    [userId, filename, filePath]
                );
            }
        }

        console.log("Seed completed successfully.");
        process.exit(0);

    } catch (error) {
        console.error("Seed failed:", error);
        process.exit(1);
    }
}

seed();