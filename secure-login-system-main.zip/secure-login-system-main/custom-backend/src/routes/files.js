const express = require("express");
const path = require("path");
const pool = require("../db");
const authenticateToken = require("../middleware/auth");

const router = express.Router();

// GET /api/files
router.get("/files", authenticateToken, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT id, filename, created_at
             FROM files
             WHERE user_id = $1
             ORDER BY id`,
            [req.userId]
        );

        res.json(result.rows);

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Server error" });
    }
});

// GET /api/files/:id
router.get("/files/:id", authenticateToken, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT id, filename, created_at
             FROM files
             WHERE id = $1 AND user_id = $2`,
            [req.params.id, req.userId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: "File not found or access denied"
            });
        }

        res.json(result.rows[0]);

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Server error" });
    }
});

// GET /api/files/:id/download
router.get("/files/:id/download", authenticateToken, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM files
             WHERE id = $1 AND user_id = $2`,
            [req.params.id, req.userId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: "File not found or access denied"
            });
        }

        const file = result.rows[0];

        res.download(
            path.resolve(file.file_path),
            file.filename
        );

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Server error" });
    }
});

module.exports = router;