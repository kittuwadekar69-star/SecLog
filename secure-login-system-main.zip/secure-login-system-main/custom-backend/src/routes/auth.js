const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const pool = require("../db");
const authenticateToken = require("../middleware/auth");
const router = express.Router();


// REGISTER
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                error: "Name, email and password are required"
            });
        }

        const existingUser = await pool.query(
            "SELECT id FROM users WHERE email = $1",
            [email]
        );

        if (existingUser.rows.length > 0) {
            return res.status(400).json({
                error: "Unable to create account"
            });
        }

        const passwordHash = await bcrypt.hash(password, 12);

        const result = await pool.query(
            `INSERT INTO users (name, email, password_hash)
             VALUES ($1, $2, $3)
             RETURNING id, name, email`,
            [name, email, passwordHash]
        );

        res.status(201).json({
            message: "Registration successful",
            user: result.rows[0]
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: "Server error"
        });
    }
});


// LOGIN
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        const result = await pool.query(
            "SELECT * FROM users WHERE email = $1",
            [email]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({
                error: "Invalid email or password"
            });
        }

        const user = result.rows[0];

        const passwordValid = await bcrypt.compare(
            password,
            user.password_hash
        );

        if (!passwordValid) {
            return res.status(401).json({
                error: "Invalid email or password"
            });
        }

        const sessionId = crypto.randomUUID();

        const token = jwt.sign(
            {
                userId: user.id,
                sessionId: sessionId
            },
            process.env.JWT_SECRET,
            {
                expiresIn: process.env.JWT_EXPIRES_IN || "2h"
            }
        );

        const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000);

        const tokenHash = crypto
            .createHash("sha256")
            .update(token)
            .digest("hex");

        await pool.query(
            `INSERT INTO sessions
             (id, user_id, token_hash, expires_at)
             VALUES ($1, $2, $3, $4)`,
            [sessionId, user.id, tokenHash, expiresAt]
        );

        res.json({
            message: "Login successful",
            token
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: "Server error"
        });
    }
});


// LOGOUT
router.post("/logout", authenticateToken, async (req, res) => {
        try {
        await pool.query(
            "UPDATE sessions SET revoked = TRUE WHERE id = $1",
            [req.sessionId]
        );

        res.json({
            message: "Logout successful"
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: "Server error"
        });
    }
});

module.exports = router;