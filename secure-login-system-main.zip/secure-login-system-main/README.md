# Secure Login System

## Overview
A secure authentication project demonstrating:
1. Custom Node/Express REST API with PostgreSQL
2. Appwrite Cloud authentication/storage implementation

## Structure
```text
secure-login-system/
├── custom-backend/
└── web/
    ├── index.html
    ├── mock-api.js
    └── appwrite-adapter.js
```

## Local Run

### Backend
```bash
cd custom-backend
npm install
npm run dev
```

### Frontend
Open `web/index.html` with VS Code Live Server.

## Custom API
Typical frontend routes:
```text
POST /auth/register
POST /auth/login
POST /auth/logout
GET  /me
GET  /files
GET  /files/:id
GET  /files/:id/download
```

Do not open `/api` as a webpage and expect HTML. Use the frontend or an API client to call the actual endpoints.

## Appwrite
Configure in `web/index.html`:
- `awEndpoint`
- `awProjectId`
- `awDatabaseId`
- `awFilesCollectionId`
- `awBucketId`

The Appwrite adapter is intended to handle registration, login, logout, current-user lookup, and file operations.

## Current Debugging Status
The latest error is:
```text
POST http://localhost:5000/api/auth/register 400
```

This indicates the browser is still reaching the Custom REST fallback. In `request()`, log the selected mode:
```javascript
console.log("CURRENT BACKEND MODE:", mode);
```
If it reports `custom`, select Appwrite and hard-refresh. If it reports `appwrite` but localhost is still called, verify that the browser is serving the latest `index.html` and that the Appwrite branch matches `/auth/register`.

## Security
- Never commit `.env`.
- Never commit bearer/JWT tokens.
- Never publish real passwords.
- Enable Appwrite row/file security.
- Verify cross-user access isolation.

## Deployment Plan
```text
Custom Backend
→ Frontend
→ PostgreSQL
→ GitHub
→ Cloud PostgreSQL
→ Render
→ Public URL
→ Appwrite
→ README
→ Submit
```

## Final Checklist
- [ ] Custom backend working
- [ ] PostgreSQL working
- [ ] Frontend working
- [ ] Appwrite register/login/me verified
- [ ] Appwrite file access verified
- [ ] User isolation verified
- [ ] GitHub secrets removed
- [ ] Cloud PostgreSQL configured
- [ ] Render deployed
- [ ] Public URL tested
- [ ] README finalized
- [ ] PDF report finalized
