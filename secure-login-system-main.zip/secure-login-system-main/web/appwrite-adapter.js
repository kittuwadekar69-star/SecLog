(function () {

  const endpoint =
    document.getElementById("awEndpoint").value.trim();

  const projectId =
    document.getElementById("awProjectId").value.trim();

  const client = new Appwrite.Client();

  client
    .setEndpoint(endpoint)
    .setProject(projectId);

  const account = new Appwrite.Account(client);

  async function register(name, email, password) {
  try {
    console.log("REGISTER INPUT:", {
      name: name,
      email: email,
      password: "***"
    });

    const user = await account.create(
    Appwrite.ID.unique(),
    email.trim(),
    password,
    name.trim()
);

    console.log("APPWRITE USER CREATED:", user);

    return {
      status: 201,
      body: {
        message: "Registration successful",
        user: {
          id: user.$id,
          name: user.name,
          email: user.email
        }
      }
    };

  } catch (error) {
    console.error("========== APPWRITE ERROR ==========");
    console.error("message:", error.message);
    console.error("type:", error.type);
    console.error("code:", error.code);
    console.error("full error:", error);
    console.error("====================================");

    return {
      status: error.code || 400,
      body: {
        error: error.message || "Unable to create account",
        type: error.type || "",
        code: error.code || 0
      }
    };
  }
}

async function login(email, password) {
    try {
        console.log("LOGIN INPUT:", {
            email: email,
            password: "***"
        });

        const session = await account.createEmailPasswordSession(
            email.trim(),
            password
        );

        console.log("APPWRITE LOGIN SUCCESS:", session);

        return {
            status: 200,
            body: {
                message: "Login successful",
                session: {
                    id: session.$id
                }
            }
        };

    } catch (error) {
        console.error("========== APPWRITE LOGIN ERROR ==========");
        console.error("message:", error.message);
        console.error("type:", error.type);
        console.error("code:", error.code);
        console.error(error);

        return {
            status: error.code || 400,
            body: {
                error: error.message || "Unable to login",
                type: error.type || "",
                code: error.code || 0
            }
        };
    }
}

  async function logout() {
    try {
      await account.deleteSession({
        sessionId: "current"
      });

      return {
        status: 200,
        body: {
          message: "Logout successful"
        }
      };

    } catch (error) {
      return {
        status: error.code || 400,
        body: {
          error: error.message
        }
      };
    }
  }

  async function me() {
    try {
      const user = await account.get();

      return {
        status: 200,
        body: {
          id: user.$id,
          name: user.name,
          email: user.email
        }
      };

    } catch (error) {
      return {
        status: error.code || 401,
        body: {
          error: error.message
        }
      };
    }
  }

  window.appwriteAdapter = {
    register,
    login,
    logout,
    me
  };

})();