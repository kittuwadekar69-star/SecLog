// Simple in-browser mock implementation.
// This is only for demonstrating the Mock mode.
// It does not contact PostgreSQL or Appwrite.

(function () {
  const USERS_KEY = "secure_login_mock_users";
  const FILES_KEY = "secure_login_mock_files";
  const SESSION_KEY = "secure_login_mock_session";

  function load(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key)) || fallback;
    } catch {
      return fallback;
    }
  }

  function save(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function createId() {
    return Date.now().toString();
  }

  function getSessionUser() {
    const session = localStorage.getItem(SESSION_KEY);

    if (!session) {
      return null;
    }

    const users = load(USERS_KEY, []);
    return users.find(u => u.id === session) || null;
  }

  window.mockApi = {

    async register(name, email, password) {
      const users = load(USERS_KEY, []);

      const existing = users.find(
        u => u.email.toLowerCase() === email.toLowerCase()
      );

      if (existing) {
        return {
          status: 409,
          body: {
            error: "Email already registered"
          }
        };
      }

      const user = {
        id: createId(),
        name,
        email,
        password
      };

      users.push(user);
      save(USERS_KEY, users);

      return {
        status: 201,
        body: {
          message: "Registration successful",
          user: {
            id: user.id,
            name: user.name,
            email: user.email
          }
        }
      };
    },

    async login(email, password) {
      const users = load(USERS_KEY, []);

      const user = users.find(
        u =>
          u.email.toLowerCase() === email.toLowerCase() &&
          u.password === password
      );

      if (!user) {
        return {
          status: 401,
          body: {
            error: "Invalid email or password"
          }
        };
      }

      localStorage.setItem(SESSION_KEY, user.id);

      return {
        status: 200,
        body: {
          message: "Login successful",
          user: {
            id: user.id,
            name: user.name,
            email: user.email
          }
        }
      };
    },

    async logout() {
      localStorage.removeItem(SESSION_KEY);

      return {
        status: 200,
        body: {
          message: "Logout successful"
        }
      };
    },

    async me() {
      const user = getSessionUser();

      if (!user) {
        return {
          status: 401,
          body: {
            error: "Not authenticated"
          }
        };
      }

      return {
        status: 200,
        body: {
          id: user.id,
          name: user.name,
          email: user.email
        }
      };
    },

    async files() {
      const user = getSessionUser();

      if (!user) {
        return {
          status: 401,
          body: {
            error: "Not authenticated"
          }
        };
      }

      const files = load(FILES_KEY, []);

      return {
        status: 200,
        body: files.filter(file => file.userId === user.id)
      };
    },

    async fileById(id) {
      const user = getSessionUser();

      if (!user) {
        return {
          status: 401,
          body: {
            error: "Not authenticated"
          }
        };
      }

      const files = load(FILES_KEY, []);

      const file = files.find(
        f => String(f.id) === String(id) && f.userId === user.id
      );

      if (!file) {
        return {
          status: 404,
          body: {
            error: "File not found or access denied"
          }
        };
      }

      return {
        status: 200,
        body: file
      };
    },

    async download(id) {
      return this.fileById(id);
    }
  };

})();